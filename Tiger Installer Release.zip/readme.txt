Current Version: https://github.com/CTayrien/TigerInstaller

Tiger OpenGL External Library Installer: free open-source library installer for game engine development in C++ & OpenGL

For use with 32-bit (x86) OpenGL projects in Visual Studio 2015
Ensure OpenGL drivers are installed
Add linker dependency: opengl32.lib
#include GLEW before GLFW

Example install directory: C:\Program Files (x86)\Microsoft Visual Studio 14.0\VC\
Creates directories: include\, lib\ and bin\ if not present
May need to set VS Project Properties to look in these directories

Image source:
http://content.sportslogos.net/logos/33/5073/full/5701_rit_tigers-alternate-2003.png